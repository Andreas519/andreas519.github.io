# Prompt 03 – Unvollständige Eingabe

## Prompt

Setze

## Antwort

Die Eingabe war unvollständig. Es wurde darum gebeten, den Satz zu vervollständigen.
