# Prompt 01 – Bilder des Raspberry Pi Zero

## Prompt

Es wurden zwei Bilder des Raspberry Pi Zero W hochgeladen.

## Antwort

Auf den beiden Fotos ist ein Raspberry Pi Zero W Version 1.1 zu sehen.

Erkennbar sind unter anderem:

- 40-polige GPIO-Stiftleiste
- Micro-USB-Anschluss für Stromversorgung
- Micro-USB-Datenanschluss
- Mini-HDMI-Ausgang
- microSD-Kartensteckplatz
- CSI-Kameraanschluss
- WLAN und Bluetooth
- kleiner Kühlkörper auf dem Prozessor

Der Raspberry Pi Zero W eignet sich gut für Kameraaufnahmen, OpenCV, einfache Formerkennung und die Kommunikation mit einem PC oder ESP32.
