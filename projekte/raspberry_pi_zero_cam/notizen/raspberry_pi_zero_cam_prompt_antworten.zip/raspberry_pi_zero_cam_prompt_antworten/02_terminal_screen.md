# Prompt 02 – Serielle Konsole im Terminal

## Prompt

Im Terminal kann man Serie aufrufen. Wie geht das?

## Antwort

Wahrscheinlich war das Programm `screen` gemeint.

Serielle Schnittstellen anzeigen:

```bash
ls /dev/tty*
```

Typische Geräte sind:

```text
/dev/ttyS0
/dev/ttyAMA0
/dev/ttyUSB0
/dev/ttyACM0
```

Eine serielle Verbindung mit 115200 Baud öffnen:

```bash
screen /dev/ttyUSB0 115200
```

`screen` beenden:

1. `Strg + A`
2. `K`
3. mit `Y` bestätigen

Falls `screen` fehlt:

```bash
sudo apt update
sudo apt install screen
```
