Befehlskette Version 3.3.4
Stand: 23.07.2026

Dateien
-------
befehlskette_beispiel_v3_3_4.py
befehlskette_v3_3_4.py
esp32_kommunikation_v1_4.py
esp-simulator.py

Neu in Version 3.3.4
--------------------
1. Die gesamte Befehlskette wird geprüft, bevor eine Verbindung zum Dobot
   aufgebaut wird. Unbekannte Befehle, falsche Parameter, doppelte Marken,
   fehlende Sprungziele und ungültige Vergleichsoperatoren führen sofort zu
   einer verständlichen Fehlermeldung.

2. wenn_wert unterstützt folgende Operatoren:
   ==  !=  <  <=  >  >=

   Alte Schreibweise, weiterhin gültig:
   ("wenn_wert", "POSITION", "POS_A", Wahr-Befehl, Falsch-Befehl)

   Neue Schreibweise:
   ("wenn_wert", "TEMPERATUR", ">=", 30, Wahr-Befehl, Falsch-Befehl)

3. warte_bis_wert unterstützt dieselben Operatoren:
   ("warte_bis_wert", "TASTER", "==", 1, "Warte auf Taster", None)

4. Der Programmablauf sendet Zustandsmeldungen an ESP32 oder Simulator:
   BEFEHLSKETTE_GEPRUEFT;13
   PROGRAMM_GESTARTET;3.3.4
   BEFEHL_GESTARTET;6;wenn_wert;Text
   BEDINGUNG;TEMPERATUR;35;>=;30;WAHR;...
   WARTE_AUF;MELDUNG;FREIGABE
   WARTE_AUF;WERT;TASTER;==;1
   BEFEHL_FERTIG;6;wenn_wert
   BEFEHLSKETTE_BEENDET;NORMAL
   PROGRAMM_BEENDET;NORMAL

ESP32-Nachrichten
-----------------
Dauerhafte Werte werden weiterhin so übertragen:
WERT;POSITION;POS_A
WERT;TASTER;1
WERT;TEMPERATUR;23.7

Test mit dem Simulator
----------------------
1. esp-simulator.py starten.
2. befehlskette_beispiel_v3_3_4.py starten.
3. Im Simulator temp25 oder temp35 eingeben.
4. Im Simulator A oder B eingeben.
5. Im Simulator F eingeben.

Hinweis
-------
Das Kommunikationsmodul bleibt Version 1.4, weil seine vorhandene senden()-
Funktion die neuen Zustandsmeldungen bereits vollständig unterstützt.
