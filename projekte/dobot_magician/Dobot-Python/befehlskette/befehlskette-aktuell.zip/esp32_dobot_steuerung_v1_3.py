from machine import Pin
import sys
import time
import random


try:
    import uselect as select
except ImportError:
    import select


VERSION = "1.3.8"
VERSIONSDATUM = "26.07.2026, 20:49 Uhr"


# ------------------------------------------------------------
# Anschlüsse
# ------------------------------------------------------------

PIN_PAUSE = 25
PIN_WEITER = 26
PIN_HALT = 27
PIN_STATUS = 33
PIN_FREI1 = 18   # 35 geht nicht
PIN_FREI2 = 32
PIN_LED = 2
PIN_LED_GELB = 19

led = Pin(PIN_LED, Pin.OUT)
led.off()

led_gelb = Pin(PIN_LED_GELB, Pin.OUT)
led_gelb.on()


# ------------------------------------------------------------
# Einstellungen
# ------------------------------------------------------------

ENTPRELLZEIT_MS = 50
SCHLEIFENPAUSE_MS = 5
STARTWARTEZEIT_MS = 1000
EMPFANGSANZEIGE_MS = 200

empfangsanzeige_aktiv = False
empfangsanzeige_ruhezustand = led.value()
empfangsanzeige_ende = 0


def empfangsanzeige_starten():
    """Zeigt eine empfangene PC-Nachricht kurz über die blaue LED an."""

    global empfangsanzeige_aktiv
    global empfangsanzeige_ruhezustand
    global empfangsanzeige_ende

    empfangsanzeige_ruhezustand = led.value()
    led.value(not empfangsanzeige_ruhezustand)
    empfangsanzeige_ende = time.ticks_add(
        time.ticks_ms(),
        EMPFANGSANZEIGE_MS,
    )
    empfangsanzeige_aktiv = True


def empfangsanzeige_pruefen():
    """Stellt nach der Empfangsanzeige den vorherigen LED-Zustand wieder her."""

    global empfangsanzeige_aktiv

    if not empfangsanzeige_aktiv:
        return

    if time.ticks_diff(time.ticks_ms(), empfangsanzeige_ende) >= 0:
        led.value(empfangsanzeige_ruhezustand)
        empfangsanzeige_aktiv = False


class Taste:
    """Speichert Zustand und Entprellung eines Tasters."""

    def __init__(self, pin_nummer, befehl):
        self.pin = Pin(
            pin_nummer,
            Pin.IN,
            Pin.PULL_UP,
        )
        self.befehl = befehl

        aktueller_zustand = self.pin.value()

        self.letzter_rohzustand = aktueller_zustand
        self.stabiler_zustand = aktueller_zustand
        self.letzte_aenderung = time.ticks_ms()

    def pruefen(self):
        """Gibt beim Drücken den zugehörigen Befehl zurück."""

        jetzt = time.ticks_ms()
        rohzustand = self.pin.value()

        if rohzustand != self.letzter_rohzustand:
            self.letzte_aenderung = jetzt
            self.letzter_rohzustand = rohzustand

        lange_genug_stabil = (
            time.ticks_diff(
                jetzt,
                self.letzte_aenderung,
            )
            >= ENTPRELLZEIT_MS
        )

        if (
            lange_genug_stabil
            and rohzustand != self.stabiler_zustand
        ):
            self.stabiler_zustand = rohzustand

            # Durch Pin.PULL_UP bedeutet 0:
            # Der Taster ist gedrückt.
            if rohzustand == 0:
                return self.befehl

        return None

# ------------------------------------------------------------
# Überwachung der Ein- und Ausgänge
# ------------------------------------------------------------
tasten = [
    Taste(PIN_PAUSE, "PAUSE"),
    Taste(PIN_WEITER, "WEITER"),
    Taste(PIN_HALT, "HALT"),
    Taste(PIN_STATUS, "STATUS"),
    Taste(PIN_FREI1, "FREIGABE"),
    Taste(PIN_FREI2, "FREI_2"),
]


UEBERWACHTE_SIGNALE = {
    "LED_gelb":      (led_gelb, 0),  # 0 keine Entprellung, 40 für 40 ms Entprellung
}

letzte_rohwerte = {}
stabile_werte = {}
aenderungszeiten = {}

eingabe_poll = select.poll()
eingabe_poll.register(
    sys.stdin,
    select.POLLIN,
)
pc_eingabepuffer = ""


def zeile_senden(text):
    """Sendet genau eine Textzeile an den PC."""

    sys.stdout.write(str(text) + "\n")

    try:
        sys.stdout.flush()
    except AttributeError:
        pass


def tasten_pruefen():
    """Prüft alle Taster und sendet neue Befehle."""

    for taste in tasten:
        befehl = taste.pruefen()

        if befehl is not None:
            zeile_senden(befehl)


AUTOMATISCHE_PC_STATUSMELDUNGEN = (
    "BEFEHLSKETTE_GEPRUEFT",
    "PROGRAMM_GESTARTET",
    "BEFEHL_GESTARTET",
    "BEFEHL_FERTIG",
    "MARKE",
    "SPRUNG",
    "WARTE_AUF",
    "BEDINGUNG",
    "BEFEHLSKETTE_BEENDET",
    "PROGRAMM_BEENDET",
)

letzte_pc_statusmeldung = ""


def led_gelb_status_senden():
    """Sendet den aktuellen Zustand der gelben LED."""

    zeile_senden(
        f"WERT;LED_gelb;{led_gelb.value()}"
    )


def esp32_status_senden():
    """Sendet eine kompakte Statusmeldung an den PC."""

    zeile_senden(
        "ESP32_STATUS;"
        f"VERSION={VERSION};"
        f"LED_BLAU={led.value()};"
        f"LED_GELB={led_gelb.value()};"
        f"SIMULATION={int(simulation_led_aktiv)}"
    )


def hilfe_senden():
    """Sendet die unterstützten PC-Befehle in einer Zeile."""

    zeile_senden(
        "ESP32_BEFEHLE;"
        "LED_GELB_EIN;"
        "LED_GELB_AUS;"
        "LED_GELB_UMSCHALTEN;"
        "LED_GELB_STATUS;"
        "SIMULATION_LED_START;min;max;"
        "SIMULATION_LED_STOP;"
        "ESP32_STATUS;"
        "PING;"
        "HILFE"
    )


def pc_nachricht_verarbeiten(nachricht):
    """Verarbeitet genau eine vom PC empfangene Nachricht."""

    global letzte_pc_statusmeldung

    if not nachricht:
        return

    teile = nachricht.split(";")
    befehl = teile[0].strip().upper()
    parameter = [teil.strip() for teil in teile[1:]]

    while parameter and parameter[-1] == "":
        parameter.pop()

    if befehl == "PC_BEREIT":
        led.on()
        zeile_senden("PC_BEREIT_BESTAETIGT")
        return

    if befehl == "PING":
        zeile_senden("PONG")
        return

    if befehl == "LED_GELB_EIN":
        simulation_led_beenden()
        led_gelb.on()
        zeile_senden("BEFEHL_AUSGEFUEHRT;LED_GELB_EIN")
        return

    if befehl == "LED_GELB_AUS":
        simulation_led_beenden()
        led_gelb.off()
        zeile_senden("BEFEHL_AUSGEFUEHRT;LED_GELB_AUS")
        return

    if befehl == "LED_GELB_UMSCHALTEN":
        simulation_led_beenden()
        led_gelb.value(not led_gelb.value())
        zeile_senden("BEFEHL_AUSGEFUEHRT;LED_GELB_UMSCHALTEN")
        return

    if befehl == "LED_GELB_STATUS":
        led_gelb_status_senden()
        return

    if befehl == "SIMULATION_LED_STOP":
        simulation_led_beenden()
        zeile_senden("BEFEHL_AUSGEFUEHRT;SIMULATION_LED_STOP")
        return

    if befehl == "SIMULATION_LED_START":
        if len(parameter) == 0:
            min_sekunden = 30
            max_sekunden = 60

        elif len(parameter) == 2:
            try:
                min_sekunden = int(parameter[0])
                max_sekunden = int(parameter[1])
            except ValueError:
                zeile_senden(
                    "BEFEHL_FEHLER;"
                    "SIMULATION_LED_START;"
                    "Zeitwerte müssen ganze Zahlen sein"
                )
                return

        else:
            zeile_senden(
                "BEFEHL_FEHLER;"
                "SIMULATION_LED_START;"
                "Syntax: SIMULATION_LED_START;min;max"
            )
            return

        try:
            simulation_led_aendert_sich(
                min_sekunden,
                max_sekunden,
            )
        except ValueError as fehler:
            zeile_senden(
                "BEFEHL_FEHLER;"
                f"SIMULATION_LED_START;{fehler}"
            )
            return

        zeile_senden(
            "BEFEHL_AUSGEFUEHRT;"
            f"SIMULATION_LED_START;"
            f"{min_sekunden};{max_sekunden}"
        )
        return

    if befehl == "ESP32_STATUS":
        esp32_status_senden()
        return

    if befehl == "HILFE":
        hilfe_senden()
        return

    if befehl in AUTOMATISCHE_PC_STATUSMELDUNGEN:
        letzte_pc_statusmeldung = nachricht
        return

    zeile_senden(
        f"UNBEKANNTER_BEFEHL;{nachricht}"
    )


def pc_nachrichten_lesen():
    """Liest und verarbeitet vorhandene PC-Nachrichten."""

    global pc_eingabepuffer

    while eingabe_poll.poll(0):
        zeichen = sys.stdin.read(1)

        if not zeichen:
            return

        if zeichen in ("\r", "\n"):
            if pc_eingabepuffer:
                nachricht = pc_eingabepuffer
                pc_eingabepuffer = ""
                pc_nachricht_verarbeiten(nachricht)
                empfangsanzeige_starten()
            continue

        pc_eingabepuffer += zeichen

        if len(pc_eingabepuffer) > 200:
            zeile_senden("FEHLER;PC_NACHRICHT_ZU_LANG")
            pc_eingabepuffer = ""


simulation_led_aktiv = False
simulation_led_min_ms = 0
simulation_led_max_ms = 0
simulation_led_naechste_aenderung = 0


def simulation_led_aendert_sich(min_sekunden, max_sekunden):
    """Startet die nicht blockierende Simulation der gelben LED."""

    global simulation_led_aktiv
    global simulation_led_min_ms
    global simulation_led_max_ms
    global simulation_led_naechste_aenderung

    if min_sekunden <= 0 or max_sekunden < min_sekunden:
        raise ValueError("Ungültiger Zeitbereich.")

    simulation_led_min_ms = int(min_sekunden * 1000)
    simulation_led_max_ms = int(max_sekunden * 1000)
    simulation_led_aktiv = True

    wartezeit_ms = random.randint(
        simulation_led_min_ms,
        simulation_led_max_ms,
    )

    simulation_led_naechste_aenderung = time.ticks_add(
        time.ticks_ms(),
        wartezeit_ms,
    )


def simulation_led_pruefen():
    """Ändert die LED, sobald die nächste Zufallszeit erreicht ist."""

    global simulation_led_naechste_aenderung

    if not simulation_led_aktiv:
        return

    jetzt = time.ticks_ms()

    if time.ticks_diff(
        jetzt,
        simulation_led_naechste_aenderung,
    ) < 0:
        return

    led_gelb.value(not led_gelb.value())

    wartezeit_ms = random.randint(
        simulation_led_min_ms,
        simulation_led_max_ms,
    )

    simulation_led_naechste_aenderung = time.ticks_add(
        jetzt,
        wartezeit_ms,
    )


def ueberwachung_initialisieren():
    """Speichert die aktuellen Anfangszustände aller Signale."""

    jetzt = time.ticks_ms()

    for name, signal in UEBERWACHTE_SIGNALE.items():
        pin, entprellzeit = signal
        wert = pin.value()

        letzte_rohwerte[name] = wert
        stabile_werte[name] = wert
        aenderungszeiten[name] = jetzt


def ueberwache():
    jetzt = time.ticks_ms()

    for name, signal in UEBERWACHTE_SIGNALE.items():
        pin, entprellzeit = signal
        aktueller_wert = pin.value()

        # Eine mögliche Änderung wurde erkannt.
        if aktueller_wert != letzte_rohwerte[name]:
            letzte_rohwerte[name] = aktueller_wert
            aenderungszeiten[name] = jetzt

        # Der neue Zustand muss lange genug stabil sein.
        zeit_stabil = time.ticks_diff(
            jetzt,
            aenderungszeiten[name],
        )

        if (
            aktueller_wert != stabile_werte[name]
            and zeit_stabil >= entprellzeit
        ):
            stabile_werte[name] = aktueller_wert

            zeile_senden(
                f"WERT;{name};{aktueller_wert}"
            )

def simulation_led_beenden():
    global simulation_led_aktiv
    simulation_led_aktiv = False    

def hauptprogramm():
    """Startet die dauerhafte Taster- und COM-Abfrage."""

    time.sleep_ms(STARTWARTEZEIT_MS)

    ueberwachung_initialisieren()
    zeile_senden("ESP32_BEREIT")

    simulation_led_aendert_sich(30, 60)
    
    while True:
        tasten_pruefen()          # speziell für Taster und Schalter
        simulation_led_pruefen()  # zufällige LED-Änderung prüfen
        ueberwache()              # allgemeine Ein- und Ausgänge
        pc_nachrichten_lesen()
        empfangsanzeige_pruefen()
        time.sleep_ms(SCHLEIFENPAUSE_MS)

def Tasten_testen():
    while True:
        for taste in tasten:
            befehl = taste.pruefen()
            if befehl is not None:
                print(befehl)
                led.value(not led.value())
            else:
                pass

try:
    hauptprogramm()

except KeyboardInterrupt:
    led.off()
    simulation_led_beenden()
    led_gelb.off()
