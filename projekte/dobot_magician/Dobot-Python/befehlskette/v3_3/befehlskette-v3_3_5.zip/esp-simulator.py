"""TCP-Server als Ersatz für einen ESP32.

Version für Befehlskette 3.3.4.

Der Simulator sendet:
- Steuerbefehle wie PAUSE, WEITER, HALT und STATUS,
- Ereignismeldungen wie FREIGABE,
- dauerhafte Werte im Format WERT;Name;Inhalt.
"""

import socket
import threading


HOST = "127.0.0.1"
PORT = 5000

STEUERBEFEHLE = {
    "p": "PAUSE",                  "pause": "PAUSE",
    "w": "WEITER",                 "weiter": "WEITER",
    "h": "HALT",                   "halt": "HALT",
    "?": "STATUS",                 "status": "STATUS",
    "a": "WERT;POSITION;POS_A",    "pos_a": "WERT;POSITION;POS_A",
    "b": "WERT;POSITION;POS_B",    "pos_b": "WERT;POSITION;POS_B",
    "f": "FREIGABE",               "freigabe": "FREIGABE",
    "t1": "WERT;TASTER;1",         "taster_ein": "WERT;TASTER;1",
    "t0": "WERT;TASTER;0",         "taster_aus": "WERT;TASTER;0",
    "temp25": "WERT;TEMPERATUR;25", "temp35": "WERT;TEMPERATUR;35",
}


def senden(verbindung, text):
    """Sendet genau eine Textzeile."""

    verbindung.sendall(f"{text}\n".encode("utf-8"))


def steuerbefehle_anzeigen():
    """Gibt den Inhalt des Dictionarys paarweise aus."""

    eintraege = list(STEUERBEFEHLE.items())

    print("Verfügbare Kurz- und Langbefehle:")

    for position in range(0, len(eintraege), 2):
        links = eintraege[position]
        rechts = eintraege[position + 1] if position + 1 < len(eintraege) else None
        links_text = f"{links[0]!r} -> {links[1]}"
        rechts_text = "" if rechts is None else f"{rechts[0]!r} -> {rechts[1]}"
        print(f"  {links_text:<38} {rechts_text}")


def empfangen(verbindung, beenden):
    """Zeigt Antworten des TCP-Clients an."""

    puffer = bytearray()
    verbindung.settimeout(0.5)

    while not beenden.is_set():
        try:
            daten = verbindung.recv(1024)
        except socket.timeout:
            continue
        except OSError:
            break

        if not daten:
            break

        puffer.extend(daten)

        while b"\n" in puffer:
            rohzeile, _, rest = puffer.partition(b"\n")
            puffer = bytearray(rest)
            text = rohzeile.decode("utf-8", errors="replace").rstrip("\r")

            print(f"\nPC: {text}")

            if text.startswith("PROGRAMM_BEENDET;") or text.startswith("BEFEHLSKETTE_BEENDET;"):
                grund = text.rsplit(";", 1)[-1]
                beschreibungen = {
                    "HALT": "Die Ausführung wurde durch HALT beendet.",
                    "NORMAL": "Die Ausführung wurde normal beendet.",
                    "TASTATURABBRUCH": "Das PC-Programm wurde mit Strg+C abgebrochen.",
                    "FEHLER": "Die Ausführung wurde wegen eines Fehlers beendet.",
                }
                print("*** " + beschreibungen.get(grund, text) + " ***")

            elif text.startswith("BEFEHL_GESTARTET;"):
                teile = text.split(";", 4)
                if len(teile) >= 4:
                    print(f"*** Befehl {teile[1]} gestartet: {teile[2]} ***")

            elif text.startswith("BEFEHL_FERTIG;"):
                teile = text.split(";", 3)
                if len(teile) >= 3:
                    print(f"*** Befehl {teile[1]} fertig: {teile[2]} ***")

            elif text.startswith("WARTE_AUF;"):
                print(f"*** PC wartet: {text.partition(';')[2]} ***")

            elif text.startswith("BEDINGUNG;"):
                print(f"*** Bedingung ausgewertet: {text.partition(';')[2]} ***")

            print("ESP> ", end="", flush=True)

    beenden.set()


def eingaben_senden(verbindung, beenden):
    """Liest Steuerbefehle, Ereignisse und Werte ein."""

    print()
    steuerbefehle_anzeigen()
    print("  'q' / 'ende' -> Simulator beenden")
    print()
    print("Beliebige ESP-Werte direkt eingeben:")
    print("  WERT;TEMPERATUR;23.7")
    print("  WERT;TASTER;1")
    print()
    print("Testablauf für Version 3.3.4:")
    print("  1. temp25 oder temp35 eingeben")
    print("  2. A oder B eingeben")
    print("  3. F eingeben")

    while not beenden.is_set():
        try:
            eingabe = input("ESP> ").strip()
        except (EOFError, KeyboardInterrupt):
            eingabe = "q"

        if eingabe.lower() in ("q", "ende"):
            beenden.set()
            return

        if not eingabe:
            continue

        nachricht = STEUERBEFEHLE.get(eingabe.lower(), eingabe)

        try:
            senden(verbindung, nachricht)
            print(f"Gesendet: {nachricht}")
        except OSError as fehler:
            print(f"Senden fehlgeschlagen: {fehler}")
            beenden.set()


def main():
    """Startet den TCP-Server und wartet auf einen Client."""

    beenden = threading.Event()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(1)

        print(f"ESP-Simulator wartet auf {HOST}:{PORT} ...")
        verbindung, adresse = server.accept()

        with verbindung:
            print(f"TCP-Client verbunden: {adresse[0]}:{adresse[1]}")
            senden(verbindung, "ESP32_BEREIT")

            empfangsthread = threading.Thread(
                target=empfangen,
                args=(verbindung, beenden),
                daemon=True,
                name="ESP-Simulator-Empfang",
            )
            empfangsthread.start()
            eingaben_senden(verbindung, beenden)

            try:
                verbindung.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

            empfangsthread.join(timeout=1.0)

    print("ESP-Simulator beendet.")


if __name__ == "__main__":
    main()
