Befehlskette Version 3.3.5

Neue Funktion:
    ("esp_senden", Nachricht[, Beschreibung])

Beispiele:
    ("esp_senden", "LED_GELB_EIN", "Gelbe LED einschalten")
    ("esp_senden", "DISPLAY;Dobot arbeitet", "Displaytext senden")

Startmenü im Beispielprogramm:
    s = Befehlskette starten
    a = vor dem Start abbrechen
    t = Texte testweise an ESP32 senden

Im Sendetest wird jede Eingabe an den ESP32 übertragen.
Die Eingabe q beendet den Sendetest und kehrt zum Startmenü zurück.

Das Kommunikationsmodul bleibt unverändert bei Version 1.4.
