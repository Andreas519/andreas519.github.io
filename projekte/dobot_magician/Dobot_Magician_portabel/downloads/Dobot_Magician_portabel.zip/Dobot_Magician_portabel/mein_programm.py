"""Hier steht das eigentliche Dobot-Programm.

Die Funktion ausfuehren(api, dType) wird automatisch von start.py aufgerufen.
Das aktuelle Beispiel liest nur Werte und bewegt den Roboter noch nicht.
"""

def ausfuehren(api, dType):
    print("HOME-Fahrt wird vorbereitet.")

    # Laufende Queue stoppen und alte Befehle löschen
    dType.SetQueuedCmdStopExec(api)
    dType.SetQueuedCmdClear(api)

    # Vorhandene Alarme löschen
    dType.ClearAllAlarmsState(api)
    dType.dSleep(300)

    # Prüfen, ob weiterhin ein Alarm aktiv ist
    alarm_result = dType.GetAlarmsState(api)
    alarm_bytes = alarm_result[0]

    if any(alarm_bytes):
        print("Abbruch: Es ist weiterhin ein Alarm aktiv.")
        print("Alarmstatus:", alarm_result)
        return

    print("Kein Alarm aktiv.")


    dType.SetHOMEParams(
        api,
        200,   # X
        0,     # Y
        80,    # Z, zunächst sicher hoch
        0,     # R
        0      # sofort setzen, nicht in die Queue
    )
    # HOME-Befehl in die Warteschlange eintragen
    home_index = dType.SetHOMECmd(
        api,
        0,  # reservierter Parameter
        1   # als Queue-Befehl
    )[0]

    print("HOME-Befehl eingereiht, Index:", home_index)

    # Warteschlange starten
    dType.SetQueuedCmdStartExec(api)

    # Warten, bis der HOME-Befehl abgearbeitet wurde
    while dType.GetQueuedCmdCurrentIndex(api)[0] < home_index:
        dType.dSleep(100)

    # Warteschlange wieder stoppen
    dType.SetQueuedCmdStopExec(api)

    print("HOME-Fahrt abgeschlossen.")

    # Position nach der HOME-Fahrt anzeigen
    pose = dType.GetPose(api)

    print("Position nach HOME:")
    print("X  = {:.2f} mm".format(pose[0]))
    print("Y  = {:.2f} mm".format(pose[1]))
    print("Z  = {:.2f} mm".format(pose[2]))
    print("R  = {:.2f}°".format(pose[3]))
    print("J1 = {:.2f}°".format(pose[4]))
    print("J2 = {:.2f}°".format(pose[5]))
    print("J3 = {:.2f}°".format(pose[6]))
    print("J4 = {:.2f}°".format(pose[7]))


def ausfuehren1(api, dType):
    # Aktuelle Position erneut abfragen
    pose = dType.GetPose(api)
    print("Position als Liste:", pose)

    # PTP-Parameter anzeigen
    print("PTP Joint:     ", dType.GetPTPJointParams(api))
    print("PTP Coordinate:", dType.GetPTPCoordinateParams(api))
    print("PTP Common:    ", dType.GetPTPCommonParams(api))

    print("\nDer Dobot wurde in diesem Beispiel nicht bewegt.")

    # --------------------------------------------------------
    # Später können hier eigene Befehle eingefügt werden.
    # Beispiel HOME – zunächst bewusst auskommentiert:
    home_index = dType.SetHOMECmd(api, 0, 1)[0]

    dType.SetQueuedCmdClear(api)
    home_index = dType.SetHOMECmd(api, 0, 1)[0]
    eing = input()
    # dType.SetQueuedCmdStartExec(api)
    # while dType.GetQueuedCmdCurrentIndex(api)[0] < home_index:
    #     dType.dSleep(100)
    # dType.SetQueuedCmdStopExec(api)
    # --------------------------------------------------------
