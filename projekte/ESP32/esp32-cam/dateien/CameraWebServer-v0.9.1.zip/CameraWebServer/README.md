# CameraWebServer

Aktuelle Version: **0.9.1**

## Systemseite und Betriebsarten

Unter `/system` zeigt die Firmware Programmversion, aktive Betriebsart,
Gerätenamen, WLAN und IP-Adresse an. Von dort kann das Modul per Schaltfläche
für den nächsten Neustart in den Station-, Access-Point- oder BLE-Modus
versetzt werden. `/device-info` stellt dieselben Geräteinformationen als JSON
bereit.

Die Umschalt-Endpunkte akzeptieren ausschließlich POST-Anfragen:

```text
POST /station-mode
POST /ap-mode
POST /ble-mode
```

## Automatischer Access-Point-Fallback

Beim Start versucht das Modul zuerst, ein gespeichertes 2,4-GHz-WLAN zu
erreichen. Gelingt das nicht, öffnet es automatisch ein eigenes WLAN:

```text
Name:     ESP32-CAM-Setup-XXXXXX
Passwort: esp32cam
Adresse:  http://192.168.4.1/
WLAN:     http://192.168.4.1/wifi-settings
```

Die sechs Zeichen am Ende des WLAN-Namens stammen aus der Geräte-ID. Dadurch
lassen sich mehrere Module unterscheiden. Im eigenen WLAN stehen Kamera,
Livebild, Einzelaufnahme, Fotoeinstellungen und WLAN-Konfiguration gemeinsam
zur Verfügung. Nach dem Speichern eines WLANs startet das Modul neu. Scheitert
auch dieser Verbindungsversuch, öffnet es wieder seinen Access Point.

## Lokale WLAN-Startdaten

`wifi_secrets.example.h` nach `wifi_secrets.h` kopieren und dort bis zu acht
WLANs eintragen. Die lokale Datei `wifi_secrets.h` wird von Git ignoriert.
Noch nicht gespeicherte Einträge werden beim Start in den NVS-Flash übernommen.
Bereits gespeicherte Einträge werden dabei nicht überschrieben. Ein leeres
Passwort kennzeichnet ein offenes WLAN.

## BLE-Notbetrieb

Das Modul meldet sich als `ESP32-CAM-Setup` und stellt einen Nordic-UART-
kompatiblen BLE-Dienst bereit. Jeder Befehl wird mit einem Zeilenumbruch
abgeschlossen.

Für den BLE-Konfigurationsmodus GPIO 13 beim Neustart gedrückt halten. Kamera-
Webserver und BLE laufen wegen des begrenzten internen RAMs des ESP32-CAM in
getrennten Betriebsarten. Nach `WLAN VERBINDEN` startet das Modul automatisch
in den Webserver-Modus neu.

BLE dient ab Version 0.9.0 nur noch als Notzugang. Es wird über GPIO 13 oder
über `POST /ble-mode` für den nächsten Neustart aktiviert. Die Blitz-LED blinkt
in diesem Modus schwach.

```text
HILFE
STATUS
WLAN LISTE
WLAN HINZUFUEGEN <SSID>|<PASSWORT>
WLAN LOESCHEN <SSID>
WLAN VERBINDEN <SSID>
```

Bis zu acht WLAN-Zugänge können gespeichert werden. Kennwörter werden im
Dialog nicht angezeigt. Der NVS-Speicher ist dauerhaft, aber nicht
verschlüsselt.

## Zeitgesteuerte Fotos

Unter `/photo-settings` lassen sich Auflösung und Aufnahmeintervall einstellen.
Der Wert `0` deaktiviert automatische Aufnahmen. Das jeweils letzte Foto steht
unter `/scheduled-photo` für den Browser oder ein PC-Programm bereit. Die
Einstellungen bleiben im NVS-Flash gespeichert.

Nach einer WLAN-Verbindung aktualisiert das Modul seine Uhr über einen externen
Zeitdienst. Eine erneute Aktualisierung erfolgt alle sechs Stunden. Anzeige und
Foto-Dateinamen verwenden die deutsche Winter- beziehungsweise Sommerzeit.

## Fotoabruf vom PC

Eine neue Einzelaufnahme kann per `GET /photo-capture` angefordert werden. Das
Windows-Programm im Ordner `WindowsPhotoClient` zeigt das empfangene JPEG an
und kann es mit Datums- und Zeitstempel im Dateinamen speichern.

## Wechsel in den BLE-Modus per HTTP

Im Webserver-Modus merkt `POST /ble-mode` den BLE-Modus vor und startet das
Modul neu. Nach dem Neustart ist der Webserver nicht mehr erreichbar und das
Modul kann per BLE konfiguriert werden.

```powershell
Invoke-RestMethod -Method Post -Uri http://192.168.x.x/ble-mode
```

Der Endpunkt besitzt keine Anmeldung und darf deshalb nur in einem
vertrauenswürdigen lokalen Netzwerk verwendet werden.
