from machine import Pin
import time

# Beispielprogramm für den ESP32
# Die eingebaute LED wird im Sekundentakt umgeschaltet.

led = Pin(2, Pin.OUT)

while True:
    led.value(not led.value())
    time.sleep(0.5)
